package com.example._006secondhomework;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "LoginServlet", value = "/api/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String msg = "";
        //设置响应的文本类型为html,编码字符为UTF-6
        response.setContentType("text/html;charset=UTF-8");
        //获取表单数据，获取用户名文本框里的值和密码框里的值
        String username = request.getParameter("id");
        String password = request.getParameter("password");
        String verificationCode = request.getParameter("verificationCode");
       // String category = new String(request.getParameter("category").getBytes("ISO-8859-1"), "UTF-8");
        Object category = request.getParameter("category");

        //获取当前的session
        HttpSession session = request.getSession();
        //保存当前的username,password,verification,category
        session.setAttribute("Name", username);
        session.setAttribute("Pass", password);
        session.setAttribute("Ver", verificationCode);
        session.setAttribute("Cate", category);
        //判断用户名和密码和验证码是不是都正确
        if (username.equals("admin") && password.equals("123") && verificationCode.equals("8774")) {
            //（sendRedirect方法可以重定向到任何的URL）
            //如果想要跳转到别的应用的资源就要用sendRedirect
            response.getWriter().println(username + "<br>" + category);
            //PrintWriter out = response.getWriter();
            //String title = "使用 GET 方法读取表单数据";
//        String docType = "<!DOCTYPE html> \n";
//        out.println(docType +
//                "<html><body>\n" +
//                "<ul>\n" +
//                "  <li><b>用户</b>："
//                + username + "\n" +
//                "  <li><b>类别</b>："
//                + category+ "\n" +
//                "</ul>\n" +
//                "</body></html>");
        } else {
            msg = "登录失败：用户名或密码或验证码错误";
            //如果使用request.setAttribute传递一些属性就需要用forward
            request.setAttribute("message", msg);
            response.getWriter().println(msg);
            response.getWriter().println("<a href=\"/login.html\">重新登陆</a>");

            // request.getRequestDispatcher("/login.html").forward(request, response);
        }
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
