package com.example._006secondhomework;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

@WebServlet(
        name = "SharedServlet",
        value = "/SharedServlet"
)
public class SharedServlet extends HttpServlet {
    @Override
    public void init() {
        this.getServletContext().setAttribute("id", 006);


        this.getServletContext().setAttribute("name", "潘玮成");


    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //设置响应的文本类型为html,编码字符为UTF-8
        response.setContentType("text/html;charset=UTF-8");
        Object id =(int) this.getServletContext().getAttribute("id");
        Object name = this.getServletContext().getAttribute("name");

        response.getWriter().println(id);
        response.getWriter().println(name);
//        if(name instanceof String) {
//            System.out.println(name);
//            response.getWriter().println(name);
//        }
        Object id1= this.getServletContext().getAttribute("id");
        Object id2= this.getServletContext().getAttribute("id");
        Object id3= this.getServletContext().getAttribute("id");
        id1 = (int)id1 + 1;
        id2 = (int)id2 + 2;
        id3 = (int)id3 + 3;
        response.getWriter().println(id1 + "   " +id2+"   "+id3);

    }
}
