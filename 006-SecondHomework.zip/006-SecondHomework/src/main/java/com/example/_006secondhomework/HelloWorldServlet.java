package com.example._006secondhomework;

import javax.lang.model.element.NestingKind;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(
        name = "HelloWorldServlet",
        value = "/HelloWorldServlet",
        initParams = {
                @WebInitParam(name = "name", value = "潘玮成"),
                @WebInitParam(name = "student_no", value = "921000720312")
        }
)
public class HelloWorldServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("GBK");
        //设置响应的文本类型为html,编码字符为GBK
        response.setContentType("text/html;charset=GBK");
        //获取表单数据，获取用户名文本框里的值和密码框里的值

        String name = this.getServletConfig().getInitParameter("name");
        String student_no = this.getServletConfig().getInitParameter("student_no");
        //获取当前的session
        HttpSession session = request.getSession();
        //保存当前的username,password,verification,category
        session.setAttribute("Name", name);
        session.setAttribute("Sid", student_no);


        response.getWriter().println("学号为" + student_no + "的" + name + "同学，你好！这是一个简单的servlet程序。");

    }
}
