package com.example._006secondhomework;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "Session2", value = "/Session2")
public class Session2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ServletContext sc = this.getServletContext();
        HttpSession session = request.getSession();

        String sc_value = (String) sc.getAttribute("sc_name");
        String session_value = (String) session.getAttribute("session_name");
        String request_value = (String) request.getAttribute("request_name");

        System.out.println(sc_value+":"+session_value+":"+request_value);
        response.getWriter().println(sc_value);
        response.getWriter().println(session_value);
        response.getWriter().println(request_value);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
