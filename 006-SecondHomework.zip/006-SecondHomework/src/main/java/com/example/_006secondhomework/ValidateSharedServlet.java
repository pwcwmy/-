package com.example._006secondhomework;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ValidateSharedServlet", value = "/ValidateSharedServlet")

public class ValidateSharedServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 1
        ServletContext sc = this.getServletContext();
        sc.setAttribute("sc_name", "sc_value");
        // 2
        HttpSession session = request.getSession();
        session.setAttribute("session_name", "session_value");
        // 3
        request.setAttribute("request_name", "request_value");

        String sc_value = (String) sc.getAttribute("sc_name");
        String session_value = (String) session.getAttribute("session_name");
        String request_value = (String) request.getAttribute("request_name");

        System.out.println(sc_value+":"+session_value+":"+request_value);

        // request.getRequestDispatcher("MyServlet2").forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
